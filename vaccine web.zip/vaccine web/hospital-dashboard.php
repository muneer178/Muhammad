<?php
// Database credentials
$hostname = 'localhost'; // Replace with your hostname
$username = 'root';      // Replace with your username
$password = '';          // Replace with your password
$database = 'user_db';   // Replace with your database name

// Establish a connection to the database
try {
    $pdo = new PDO("mysql:host=$hostname;dbname=$database", $email, $password);
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to receive appointments booked by admin
function receiveAppointments($pdo, $id) {
    // Fetch appointments where status is 'Confirmed' for the hospital
    $sql = "SELECT * FROM booking WHERE id = :id AND status = 'Confirmed'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $hospital_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to update vaccination status
function updateVaccinationStatus($pdo, $appointment_id, $vaccination_status) {
    // Update vaccination status for a specific appointment
    $sql = "UPDATE booking SET vaccination_status = :vaccination_status WHERE appointment_id = :appointment_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':vaccination_status', $vaccination_status, PDO::PARAM_STR);
    $stmt->bindParam(':appointment_id', $appointment_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Handle form submissions or direct page requests

// Example: Check if form submitted to update vaccination status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_id'], $_POST['vaccination_status'])) {
    $appointment_id = $_POST['appointment_id'];
    $vaccination_status = $_POST['vaccination_status'];

    if (updateVaccinationStatus($pdo, $appointment_id, $vaccination_status)) {
        echo "Vaccination status updated successfully";
    } else {
        echo "Error updating vaccination status";
    }
}

// Example: Display appointments booked by admin
$hospital_id = 1; // Replace with the actual hospital ID
$appointments = receiveAppointments($pdo, $hospital_id);

// Display appointments
foreach ($appointments as $appointment) {
    echo "<p>Appointment ID: " . $appointment['appointment_id'] . "</p>";
    echo "<p>User ID: " . $appointment['user_id'] . "</p>";
    echo "<p>Appointment Date: " . $appointment['appointment_date'] . "</p>";
    
    // Display form to update vaccination status
    echo "<form method='post'>";
    echo "<input type='hidden' name='appointment_id' value='" . $appointment['appointment_id'] . "'>";
    echo "<label>Vaccination Status:</label>";
    echo "<select name='vaccination_status'>";
    echo "<option value='Vaccinated'>Vaccinated</option>";
    echo "<option value='Not Vaccinated'>Not Vaccinated</option>";
    echo "</select>";
    echo "<input type='submit' value='Update'>";
    echo "</form>";
    
    echo "<hr>";
}
?>

