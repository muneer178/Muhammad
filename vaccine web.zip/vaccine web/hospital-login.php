<link rel="stylesheet" href="style_login.css">
<form action="hospital-login-check.php" method="POST">
<center>
<h1>Hospital Login </h1>
</center>
<label>Email:</label>
  <input type="email" name="email" required>

  <label>Password:</label>
  <input type="password" name="password" required>

  <br>
  <button type="submit" class="button">Log in</button>

  <div class="social">
          <div class="lb"><a href="hospital-reg.php">Sign Up</div></a>
    

    
        </div>
        <br>
   
</form>

