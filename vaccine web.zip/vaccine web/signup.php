






<link rel="stylesheet" href="style_login.css">

<form action="register.php" method="POST" >
<center>
  <h1>Register Now</h1>
</center> 
<label>Name:</label>
  <input type="text" name="name" required>

  <label>Email:</label>
  <input type="email" name="email" required>

  <label>Password:</label>
  <input type="password" name="password" required>
<br>
  <button type="submit" class="button">Sign up</button>
  

  <div class="social">
          
	<div class="back"><a href="login.php">back</a></div>
       
        </div>

</form>
